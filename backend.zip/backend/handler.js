const AWS = require('aws-sdk')
const bcrypt = require('bcryptjs')
const dynamodb = new AWS.DynamoDB.DocumentClient();
const ses = new AWS.SES();

const generateOtp = () => {
    return Math.floor(100000 + Math.random() * 900000).toString();
}

const sendOtpEmail = async (email, otp) => {
    const params = {
        Destination: { ToAddresses: [email] },
        message: {
            Body: {
                Text: {
                    Data: `Your OTP is ${otp}.It is valid for 5 minutes`,
                },

            },
            Subject: { Data: 'Your otp for Telecure' },
        },
        Source: 'telecure07@gmail.com',
    };
    await ses.sendEmail(params).promise();
}

module.exports.signup = async (event) => {


    try {
        const { email, password, name } = JSON.parse(event.body);

        const checkparams = {
            TableName: 'Users',
            Item: {
                userId: email
            }
        }
        const user = await dynamodb.get(checkparams).promise();

        if (user.Item) {
            return {
                statusCode: 400,
                body: JSON.stringify({ message: 'user already exist!' }),
            }
        }

        // Generate OTP and save to DynamoDB
        const otp = generateOtp();
        const otpExpiry = Math.floor(Date.now() / 1000) * 300; //5 minutes
        hashedPassword = await bcrypt.hash(password, 10)
        const params = {
            TableName: process.env.USERS_TABLE,
            Item: {
                userId: email,
                name,
                password: hashedPassword,
                otp,
                otpExpiry,
                verified: false,
            },
        };

        await dynamodb.put(params).promise();
        await sendOtpEmail(email, otp);

        return {
            statusCode: 200,
            body: JSON.stringify({ message: 'User signed up successfully' }),
        };
    } catch (error) {
        console.error(error);
        return {
            statusCode: 500,
            body: JSON.stringify({ message: 'An error occurred during signup.' }),
        };
    }
};

module.exports.verifyOtp = async (event) => {
    try {
        const { email, otp } = Json.parse(event.body);

        const params = {
            TableName: process.env.USERS_TABLE,
            Key: { userId: email },
        };
        const user = await dynamodb.get(params).promise();

        if (!user.Item) {
            return {
                statusCode: 404,
                body: JSON.stringify({ message: 'User not found!' }),
            };
        }

        if (user.Item.otp !== otp || user.Item.otpExpiry < Math.floor(Date.now() / 1000)) {
            return {
                statusCode: 400,
                body: JSON.stringify({ message: 'Invalid or expired OTP!' }),
            };
        }

        const updateParams = {
            TableName: process.env.USERS_TABLE,
            Key: { userId: email },
            UpdateExpression: 'SET verified=:verified REMOVE otp,otpExpiry',
            ExpressionAttributeValues: {
                ':verified': true
            },
        };
        await dynamodb.update(updateParams).promise();
        return {
            statusCode: 200,
            body: JSON.stringify({ message: 'User verified successfully!' }),
        };
    } catch (error) {
        console.error(error);
        return {
            statusCode: 500,
            body: JSON.stringify({ message: 'An error occurred during OTP verification.' }),
        };
    }
}


module.exports.login = async (event) => {
    try {
        const { email, password } = JSON.parse(event.body);

        const params = {
            TableName: process.env.USERS_TABLE,
            Key: { userId: email },
        };
        const user = await dynamoDb.get(params).promise();

        if (!user.Item) {
            return {
                statusCode: 404,
                body: JSON.stringify({ message: 'User not found!' }),
            };
        }

        if (!user.Item.verified) {
            return {
                statusCode: 403,
                body: JSON.stringify({ message: 'User is not verified. Complete OTP verification first.' }),
            };
        }

        const isPasswordCorrect = await bcrypt.compare(password, user.Item.password);

        if (!isPasswordCorrect) {
            return {
                statusCode: 400,
                body: JSON.stringify({ message: 'Invalid password!' }),
            };
        }

        return {
            statusCode: 200,
            body: JSON.stringify({ message: 'Login successful' }),
        };
    } catch (error) {
        console.error(error);
        return {
            statusCode: 500,
            body: JSON.stringify({ message: 'An error occurred during login.' }),
        };
    }
};

module.exports.exports.getAppointments = async (event) => {
    try {
        const userId = event.requestContext.authorizer.principalId;

        const params = {
            TableName: process.env.APPOINTMENTS_TABLE,
            KeyConditionExpression: 'userId = :userId',
            ExpressionAttribuiteValues: {
                'userId': userId,
            },
        };
        const result = await dynamodb.query(params).promise();
        return {
            statusCode: 200,
            body: JSON.stringify({ appointments: result.Items }),
        };
    }
    catch (error) {
        console.error(error);
        return {
            statusCode: 500,
            body: JSON.stringify({ message: 'An error occurred while fetching appointments.' }),
        };
    }
};

module.exports.createAppointment = async (event) => {
    try {
        const { doctorId, date, time } = JSON.parse(event.body);
        const userId = event.requestContext.authorizer.principalId;

        const appointmentId = crypto.randomBytes(16).toString('hex');
        const params = {
            TableName: process.env.APPOINTMENTS_TABLE,
            Item: {
                appointmentId,
                userId,
                doctorId,
                date,
                time,
                status: 'scheduled', // default status
            },
        };
        await dynamoDb.put(params).promise();

        return {
            statusCode: 200,
            body: JSON.stringify({ message: 'Appointment created successfully', appointmentId }),
        };
    } catch {
        console.error(error);
        return {
            statusCode: 500,
            body: JSON.stringify({ message: 'An error occurred while creating the appointment.' }),
        };
    }
};

