const AWS = require('aws-sdk');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const dynamoDb = new AWS.DynamoDB.DocumentClient();

module.exports.signup = async (event) => {
  const { name, email, password, confirmPassword } = JSON.parse(event.body);
  
  if (password !== confirmPassword) {
    return {
      statusCode: 400,
      body: JSON.stringify({ message: 'Passwords do not match' }),
    };
  }

  const userId = `user-${Date.now()}`;
  const hashedPassword = await bcrypt.hash(password, 10);

  const params = {
    TableName: process.env.USERS_TABLE,
    Item: {
      userId,
      name,
      email,
      password: hashedPassword,
    },
  };

  try {
    await dynamoDb.put(params).promise();

    // Generate JWT token
    const token = jwt.sign({ userId, email }, 'secretKey', { expiresIn: '1h' });

    return {
      statusCode: 200,
      body: JSON.stringify({ message: 'User registered successfully', token }),
    };
  } catch (error) {
    console.error(error);
    return {
      statusCode: 500,
      body: JSON.stringify({ message: 'An error occurred while signing up the user' }),
    };
  }
};

module.exports.login = async (event) => {
  const { email, password } = JSON.parse(event.body);

  const params = {
    TableName: process.env.USERS_TABLE,
    Key: { email },
  };

  try {
    const result = await dynamoDb.get(params).promise();
    const user = result.Item;

    if (!user) {
      return {
        statusCode: 404,
        body: JSON.stringify({ message: 'User not found' }),
      };
    }

    const isPasswordCorrect = await bcrypt.compare(password, user.password);
    if (!isPasswordCorrect) {
      return {
        statusCode: 401,
        body: JSON.stringify({ message: 'Invalid password' }),
      };
    }

    // Generate JWT token
    const token = jwt.sign({ userId: user.userId, email: user.email }, 'secretKey', { expiresIn: '1h' });

    return {
      statusCode: 200,
      body: JSON.stringify({ token }),
    };
  } catch (error) {
    console.error(error);
    return {
      statusCode: 500,
      body: JSON.stringify({ message: 'An error occurred while logging in' }),
    };
  }
};
