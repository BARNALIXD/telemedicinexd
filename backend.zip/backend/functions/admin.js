const AWS = require('aws-sdk');

const dynamoDb = new AWS.DynamoDB.DocumentClient();
const DOCTORS_TABLE = process.env.DOCTORS_TABLE;

// Get All Doctors
module.exports.getAllDoctors = async () => {
  const params = {
    TableName: DOCTORS_TABLE,
  };

  try {
    const result = await dynamoDb.scan(params).promise();
    return {
      statusCode: 200,
      body: JSON.stringify(result.Items),
    };
  } catch (error) {
    console.error(error);
    return {
      statusCode: 500,
      body: JSON.stringify({ message: 'An error occurred while fetching doctors' }),
    };
  }
};

// Update Doctor Status
module.exports.updateDoctorStatus = async (event) => {
  const { doctorId } = event.pathParameters;
  const { status } = JSON.parse(event.body);

  if (!['ACTIVE', 'INACTIVE'].includes(status)) {
    return {
      statusCode: 400,
      body: JSON.stringify({ message: 'Invalid status value. Use ACTIVE or INACTIVE.' }),
    };
  }

  const params = {
    TableName: DOCTORS_TABLE,
    Key: { doctorId },
    UpdateExpression: 'set #status = :status',
    ExpressionAttributeNames: { '#status': 'status' },
    ExpressionAttributeValues: { ':status': status },
    ReturnValues: 'UPDATED_NEW',
  };

  try {
    const result = await dynamoDb.update(params).promise();
    return {
      statusCode: 200,
      body: JSON.stringify({ message: 'Doctor status updated successfully', data: result.Attributes }),
    };
  } catch (error) {
    console.error(error);
    return {
      statusCode: 500,
      body: JSON.stringify({ message: 'An error occurred while updating doctor status' }),
    };
  }
};
