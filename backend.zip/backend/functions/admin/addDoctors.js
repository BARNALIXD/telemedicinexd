const AWS = require('aws-sdk');
const dynamoDb = new AWS.DynamoDB.DocumentClient();

module.exports.addDoctors = async (event) => {
    const { name, email, specialty } = JSON.parse(event.body);
    const doctorId = `doctor-${Date.now()}`;

    const params = {
        TableName: process.env.USERS_TABLE,
        Item: { userId: doctorId, name, email, role: 'doctor', specialty },
    };

    try {
        await dynamoDb.put(params).promise();
        return { statusCode: 201, body: JSON.stringify({ message: 'Doctor added', doctorId }) };
    } catch (error) {
        console.error(error);
        return { statusCode: 500, body: JSON.stringify({ message: 'Error adding doctor' }) };
    }
};
