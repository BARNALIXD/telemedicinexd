const AWS = require('aws-sdk');
const dynamoDb = new AWS.DynamoDB.DocumentClient();

module.exports.listUserAppointments = async (event) => {
    const { userId } = event.pathParameters;

    const params = {
        TableName: process.env.APPOINTMENTS_TABLE,
        IndexName: 'UserIndex',
        KeyConditionExpression: 'userId = :userId',
        ExpressionAttributeValues: { ':userId': userId },
    };

    try {
        const result = await dynamoDb.query(params).promise();
        return { statusCode: 200, body: JSON.stringify(result.Items) };
    } catch (error) {
        console.error(error);
        return { statusCode: 500, body: JSON.stringify({ message: 'Error retrieving user appointments' }) };
    }
};
