const AWS = require('aws-sdk');
const dynamoDb = new AWS.DynamoDB.DocumentClient();

module.exports.updateDoctors = async (event) => {
    const { doctorId } = event.pathParameters;
    const { name, specialty } = JSON.parse(event.body);

    const params = {
        TableName: process.env.USERS_TABLE,
        Key: { userId: doctorId },
        UpdateExpression: 'set #name = :name, specialty = :specialty',
        ExpressionAttributeNames: { '#name': 'name' },
        ExpressionAttributeValues: { ':name': name, ':specialty': specialty },
    };

    try {
        await dynamoDb.update(params).promise();
        return { statusCode: 200, body: JSON.stringify({ message: 'Doctor updated successfully' }) };
    } catch (error) {
        console.error(error);
        return { statusCode: 500, body: JSON.stringify({ message: 'Error updating doctor' }) };
    }
};
