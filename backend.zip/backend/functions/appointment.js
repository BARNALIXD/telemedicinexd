const AWS = require('aws-sdk');
const { v4: uuidv4 } = require('uuid');

const dynamoDb = new AWS.DynamoDB.DocumentClient();
const APPOINTMENTS_TABLE = process.env.APPOINTMENTS_TABLE;
const DOCTORS_TABLE = process.env.DOCTORS_TABLE;
const USERS_TABLE = process.env.USERS_TABLE;

// Create an Appointment
module.exports.createAppointment = async (event) => {
  const { patientId, doctorId, appointmentDate, appointmentTime, category } = JSON.parse(event.body);

  const appointmentId = `appointment-${uuidv4()}`;

  const params = {
    TableName: APPOINTMENTS_TABLE,
    Item: {
      appointmentId,
      patientId,
      doctorId,
      appointmentDate,
      appointmentTime,
      category,
      status: 'SCHEDULED', // Default status
    },
  };

  try {
    await dynamoDb.put(params).promise();
    return {
      statusCode: 201,
      body: JSON.stringify({ message: 'Appointment created successfully', appointmentId }),
    };
  } catch (error) {
    console.error(error);
    return {
      statusCode: 500,
      body: JSON.stringify({ message: 'An error occurred while creating the appointment' }),
    };
  }
};

// Fetch Appointments (for Patients, Doctors, or Admins)
module.exports.getAppointments = async (event) => {
  const { role, id } = event.queryStringParameters;

  if (!role || !id) {
    return {
      statusCode: 400,
      body: JSON.stringify({ message: 'Role and ID are required query parameters' }),
    };
  }

  let filterExpression = '';
  let expressionAttributeValues = {};

  if (role === 'patient') {
    filterExpression = 'patientId = :id';
    expressionAttributeValues[':id'] = id;
  } else if (role === 'doctor') {
    filterExpression = 'doctorId = :id';
    expressionAttributeValues[':id'] = id;
  }

  const params = {
    TableName: APPOINTMENTS_TABLE,
    FilterExpression: filterExpression,
    ExpressionAttributeValues: expressionAttributeValues,
  };

  try {
    const result = await dynamoDb.scan(params).promise();
    return {
      statusCode: 200,
      body: JSON.stringify(result.Items),
    };
  } catch (error) {
    console.error(error);
    return {
      statusCode: 500,
      body: JSON.stringify({ message: 'An error occurred while fetching appointments' }),
    };
  }
};
