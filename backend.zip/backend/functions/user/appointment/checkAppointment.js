const AWS = require('aws-sdk');
const dynamoDb = new AWS.DynamoDB.DocumentClient();

module.exports.checkAppointment = async (event) => {
    const { appointmentId } = event.pathParameters;

    const params = {
        TableName: process.env.APPOINTMENTS_TABLE,
        Key: { appointmentId },
    };

    try {
        const result = await dynamoDb.get(params).promise();
        if (!result.Item) {
            return { statusCode: 404, body: JSON.stringify({ message: 'Appointment not found' }) };
        }
        return { statusCode: 200, body: JSON.stringify(result.Item) };
    } catch (error) {
        console.error(error);
        return { statusCode: 500, body: JSON.stringify({ message: 'Error retrieving appointment' }) };
    }
};
