const AWS = require('aws-sdk');
const dynamoDb = new AWS.DynamoDB.DocumentClient();

module.exports.bookAppointment = async (event) => {
    const { userId, doctorId, date, time, issue } = JSON.parse(event.body);
    const appointmentId = `appointment-${Date.now()}`;

    const params = {
        TableName: process.env.APPOINTMENTS_TABLE,
        Item: { appointmentId, userId, doctorId, date, time, issue, status: 'booked' },
    };

    try {
        await dynamoDb.put(params).promise();
        return { statusCode: 201, body: JSON.stringify({ message: 'Appointment booked', appointmentId }) };
    } catch (error) {
        console.error(error);
        return { statusCode: 500, body: JSON.stringify({ message: 'Error booking appointment' }) };
    }
};
