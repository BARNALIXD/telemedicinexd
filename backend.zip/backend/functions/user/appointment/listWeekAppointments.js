const AWS = require('aws-sdk');
const dynamoDb = new AWS.DynamoDB.DocumentClient();
const moment = require('moment');

module.exports.listWeekAppointments = async (event) => {
    const { userId } = event.pathParameters;
    const startDate = moment().startOf('week').format('YYYY-MM-DD');
    const endDate = moment().endOf('week').format('YYYY-MM-DD');

    const params = {
        TableName: process.env.APPOINTMENTS_TABLE,
        IndexName: 'UserIndex',
        KeyConditionExpression: 'userId = :userId AND #date BETWEEN :start AND :end',
        ExpressionAttributeNames: { '#date': 'date' },
        ExpressionAttributeValues: { ':userId': userId, ':start': startDate, ':end': endDate },
    };

    try {
        const result = await dynamoDb.query(params).promise();
        return { statusCode: 200, body: JSON.stringify(result.Items) };
    } catch (error) {
        console.error(error);
        return { statusCode: 500, body: JSON.stringify({ message: 'Error retrieving weekly appointments' }) };
    }
};
