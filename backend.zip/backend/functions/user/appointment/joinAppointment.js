const AWS = require('aws-sdk');
const { generateMeetingLink } = require('../../utils/zoom'); // Assuming a utility to handle Zoom meetings

module.exports.joinAppointment = async (event) => {
    const { appointmentId } = event.pathParameters;

    const params = {
        TableName: process.env.APPOINTMENTS_TABLE,
        Key: { appointmentId },
    };

    try {
        const result = await dynamoDb.get(params).promise();
        if (!result.Item) {
            return { statusCode: 404, body: JSON.stringify({ message: 'Appointment not found' }) };
        }

        // Generate meeting link
        const meetingLink = await generateMeetingLink(result.Item);

        return {
            statusCode: 200,
            body: JSON.stringify({ meetingLink }),
        };
    } catch (error) {
        console.error(error);
        return { statusCode: 500, body: JSON.stringify({ message: 'Error joining appointment' }) };
    }
};
