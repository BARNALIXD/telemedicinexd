const AWS = require('aws-sdk');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');

const dynamoDb = new AWS.DynamoDB.DocumentClient();

module.exports.login = async (event) => {
    const { email, password } = JSON.parse(event.body);

    const params = { TableName: process.env.USERS_TABLE, Key: { email } };

    try {
        const result = await dynamoDb.get(params).promise();

        if (!result.Item) {
            return { statusCode: 404, body: JSON.stringify({ message: 'User not found' }) };
        }

        const isValid = await bcrypt.compare(password, result.Item.hashedPassword);
        if (!isValid) {
            return { statusCode: 401, body: JSON.stringify({ message: 'Invalid credentials' }) };
        }

        const token = jwt.sign(
            { userId: result.Item.userId, email: result.Item.email },
            process.env.JWT_SECRET, // Use a secret from environment variables
            { expiresIn: '1h' }
        );
        return { statusCode: 200, body: JSON.stringify({ token }) };
    } catch (error) {
        console.error(error);
        return { statusCode: 500, body: JSON.stringify({ message: 'Login failed' }) };
    }
};
