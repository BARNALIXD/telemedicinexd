const AWS = require('aws-sdk');
const dynamoDb = new AWS.DynamoDB.DocumentClient();

module.exports.userExists = async (event) => {
    const { email } = event.queryStringParameters;

    if (!email) {
        return {
            statusCode: 400,
            body: JSON.stringify({ message: 'Email is required' }),
        };
    }

    const params = {
        TableName: process.env.USERS_TABLE,
        Key: { email },
    };

    try {
        const result = await dynamoDb.get(params).promise();
        if (result.Item) {
            return {
                statusCode: 200,
                body: JSON.stringify({ exists: true, message: 'User exists' }),
            };
        }
        return {
            statusCode: 404,
            body: JSON.stringify({ exists: false, message: 'User does not exist' }),
        };
    } catch (error) {
        console.error(error);
        return { statusCode: 500, body: JSON.stringify({ message: 'Error checking user existence' }) };
    }
};
