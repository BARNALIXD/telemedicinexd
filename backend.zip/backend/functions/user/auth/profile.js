const AWS = require('aws-sdk');
const dynamoDb = new AWS.DynamoDB.DocumentClient();

module.exports.profile = async (event) => {
    const { userId } = event.pathParameters;

    const params = {
        TableName: process.env.USERS_TABLE,
        Key: { userId },
    };

    try {
        const result = await dynamoDb.get(params).promise();
        if (!result.Item) {
            return { statusCode: 404, body: JSON.stringify({ message: 'User not found' }) };
        }
        return { statusCode: 200, body: JSON.stringify(result.Item) };
    } catch (error) {
        console.error(error);
        return { statusCode: 500, body: JSON.stringify({ message: 'Error retrieving profile' }) };
    }
};
