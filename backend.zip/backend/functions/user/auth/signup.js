const AWS = require('aws-sdk');
const Cognito = new AWS.CognitoIdentityServiceProvider();
const dynamoDb = new AWS.DynamoDB.DocumentClient();

module.exports.signup = async (event) => {
    const { name, email, password, phoneNumber } = JSON.parse(event.body);

    const cognitoParams = {
        ClientId: process.env.COGNITO_CLIENT_ID,
        Username: email,
        Password: password,
        UserAttributes: [
            { Name: 'name', Value: name },
            { Name: 'phone_number', Value: phoneNumber },
        ],
    };

    try {
        const result = await Cognito.signUp(cognitoParams).promise();
        const userId = result.UserSub;

        const params = {
            TableName: process.env.USERS_TABLE,
            Item: { userId, name, email, phoneNumber, role: 'user' },
        };

        await dynamoDb.put(params).promise();

        return { statusCode: 201, body: JSON.stringify({ message: 'Signup successful', userId }) };
    } catch (error) {
        console.error(error);
        return { statusCode: 500, body: JSON.stringify({ message: 'Error during signup' }) };
    }
};
