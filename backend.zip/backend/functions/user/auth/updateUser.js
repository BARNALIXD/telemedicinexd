const AWS = require('aws-sdk');
const dynamoDb = new AWS.DynamoDB.DocumentClient();

module.exports.updateUser = async (event) => {
    const { userId } = event.pathParameters;
    const { name, phoneNumber } = JSON.parse(event.body);

    if (!userId || (!name && !phoneNumber)) {
        return {
            statusCode: 400,
            body: JSON.stringify({ message: 'UserId and at least one field to update are required' }),
        };
    }

    const updateExpressions = [];
    const expressionAttributeValues = {};

    if (name) {
        updateExpressions.push('#name = :name');
        expressionAttributeValues[':name'] = name;
    }

    if (phoneNumber) {
        updateExpressions.push('phoneNumber = :phoneNumber');
        expressionAttributeValues[':phoneNumber'] = phoneNumber;
    }

    const params = {
        TableName: process.env.USERS_TABLE,
        Key: { userId },
        UpdateExpression: `SET ${updateExpressions.join(', ')}`,
        ExpressionAttributeNames: { '#name': 'name' },
        ExpressionAttributeValues: expressionAttributeValues,
    };

    try {
        await dynamoDb.update(params).promise();
        return { statusCode: 200, body: JSON.stringify({ message: 'Profile updated' }) };
    } catch (error) {
        console.error(error);
        return { statusCode: 500, body: JSON.stringify({ message: 'Error updating profile' }) };
    }
};
