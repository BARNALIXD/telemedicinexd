const AWS = require('aws-sdk');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const { v4: uuidv4 } = require('uuid');

const dynamoDb = new AWS.DynamoDB.DocumentClient();
const DOCTORS_TABLE = process.env.DOCTORS_TABLE;
const JWT_SECRET = process.env.JWT_SECRET;

// Doctor Signup
module.exports.signup = async (event) => {
  const { name, email, password, category, phoneNumber } = JSON.parse(event.body);

  if (!name || !email || !password || !category || !phoneNumber) {
    return {
      statusCode: 400,
      body: JSON.stringify({ message: 'All fields are required.' }),
    };
  }

  const hashedPassword = await bcrypt.hash(password, 10);
  const doctorId = `doctor-${uuidv4()}`;

  const params = {
    TableName: DOCTORS_TABLE,
    Item: {
      doctorId,
      name,
      email,
      hashedPassword,
      category,
      phoneNumber,
      status: 'INACTIVE', // Default status set to inactive, admin activates it
    },
  };

  try {
    await dynamoDb.put(params).promise();
    return {
      statusCode: 201,
      body: JSON.stringify({ message: 'Doctor registered successfully', doctorId }),
    };
  } catch (error) {
    console.error(error);
    return {
      statusCode: 500,
      body: JSON.stringify({ message: 'An error occurred while registering the doctor.' }),
    };
  }
};

// Doctor Login
module.exports.login = async (event) => {
  const { email, password } = JSON.parse(event.body);

  if (!email || !password) {
    return {
      statusCode: 400,
      body: JSON.stringify({ message: 'Email and password are required.' }),
    };
  }

  const params = {
    TableName: DOCTORS_TABLE,
    FilterExpression: 'email = :email',
    ExpressionAttributeValues: {
      ':email': email,
    },
  };

  try {
    const result = await dynamoDb.scan(params).promise();

    if (result.Items.length === 0) {
      return {
        statusCode: 404,
        body: JSON.stringify({ message: 'Doctor not found.' }),
      };
    }

    const doctor = result.Items[0];

    // Check if the doctor is active
    if (doctor.status !== 'ACTIVE') {
      return {
        statusCode: 403,
        body: JSON.stringify({ message: 'Your account is not active. Please contact admin.' }),
      };
    }

    // Validate password
    const isPasswordValid = await bcrypt.compare(password, doctor.hashedPassword);
    if (!isPasswordValid) {
      return {
        statusCode: 401,
        body: JSON.stringify({ message: 'Invalid credentials.' }),
      };
    }

    // Generate JWT token
    const token = jwt.sign(
      { doctorId: doctor.doctorId, email: doctor.email },
      JWT_SECRET,
      { expiresIn: '1h' }
    );

    return {
      statusCode: 200,
      body: JSON.stringify({ message: 'Login successful', token }),
    };
  } catch (error) {
    console.error(error);
    return {
      statusCode: 500,
      body: JSON.stringify({ message: 'An error occurred while logging in.' }),
    };
  }
};
